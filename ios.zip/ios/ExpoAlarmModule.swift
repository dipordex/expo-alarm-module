import EventKit
import AVFoundation
import CommonCrypto

@objc(ExpoAlarmModule)
class ExpoAlarmModule: NSObject, UNUserNotificationCenterDelegate, AVAudioPlayerDelegate  {
    var isEditMode = false
    public static var audioPlayer: AVAudioPlayer?
    
    private let notificationScheduler: NotificationSchedulerDelegate = NotificationScheduler()
    private let manager: Manager = Manager();
    
    public override init() {
        super.init()
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
        } catch let error as NSError{
            print("could not set session. err:\(error.localizedDescription)")
        }
        do {
            try AVAudioSession.sharedInstance().setActive(true)
        } catch let error as NSError{
            print("could not active session. err:\(error.localizedDescription)")
        }
        
        notificationScheduler.requestAuthorization()
        notificationScheduler.registerNotificationCategories()
        UNUserNotificationCenter.current().delegate = self
        
        // Add observer for applicationDidBecomeActive
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(applicationDidBecomeActive),
            name: UIApplication.didBecomeActiveNotification,
            object: nil
        )
    }
    
    @objc(multiply:withB:withResolver:withRejecter:)
    func multiply(a: Float, b: Float, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        resolve((a*b))
    }
    
    @objc(set:withResolver:withRejecter:)
    func set(alarm: NSDictionary, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        let alarmToUse = Alarm(dictionary: alarm as! NSMutableDictionary);
        
        manager.schedule(alarmToUse);
        
        resolve(nil)
    }
    
    @objc(enable:withResolver:withRejecter:)
    func enable(uid: String, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        manager.enable(uid)
        
        resolve(nil)
    }
    
    @objc(disable:withResolver:withRejecter:)
    func disable(uid: String, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        manager.disable(uid)
        
        resolve(nil)
    }
    
    
    @objc(stop)
    func stop() -> Void {
        manager.stop();
    }
    
    @objc(get:withResolver:withRejecter:)
    func get(uid: String, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        let alarm: Alarm! = manager.getAlarm(uid);
        if(alarm != nil) {
            let alarmSerialized: NSDictionary = alarm.toDictionary();
            resolve(alarmSerialized)
        } else {
            resolve(nil)
        }
    }
    
    @objc(getAll:withRejecter:)
    func getAll(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        let alarmArray: [Alarm] = manager.getAllAlarms();
        
        let alarmDictionaryArray = alarmArray.map { alarm -> NSDictionary in
            return alarm.toDictionary()
        }
        
        if(alarmArray.count > 0) {
            resolve(alarmDictionaryArray)
        } else {
            resolve(nil)
        }    }
    
    @objc(remove:withResolver:withRejecter:)
    func remove(uid: String, resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        manager.remove(uid)
        
        resolve(nil)
    }
    
    @objc(removeAll:withRejecter:)
    func removeAll(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        manager.removeAll();
        
        resolve(nil)
    }
    
    @objc(getState:withRejecter:)
    func getState(resolve:RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
        resolve(manager.getCurrentPlayingAlarm())
    }
    
    
    // The method will be called on the delegate only if the application is in the foreground. If the method is not implemented or the handler is not called in a timely manner then the notification will not be presented. The application can choose to have the notification presented as a sound, badge, alert and/or in the notification list. This decision should be based on whether the information in the notification is otherwise visible to the user.
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print("🔔 willPresent triggered for notification: \(notification.request.identifier)")
        let userInfo = notification.request.content.userInfo
        print("📦 Notification userInfo: \(userInfo)")

        guard
            let snoozeEnabled = userInfo["snooze"] as? Bool,
            let soundName = userInfo["soundName"] as? String,
            let uidStr = userInfo["uid"] as? String
        else {
            print("❌ Missing expected fields in notification userInfo")
            completionHandler([])
            return
        }

        manager.setCurrentPlayingAlarm(uidStr)

        // 🔍 Check if pre-downloaded file path is passed
        let localPath = userInfo["localSoundPath"] as? String

        playSound(soundName, localPath: localPath) {
            DispatchQueue.main.async {
            
                if #available(iOS 14.0, *) {
                    completionHandler([.sound, .banner, .list])
                } else {
                    completionHandler(.alert)
                }
            }
        }
    }
    
    
    
    @objc func applicationDidBecomeActive() {
        notificationScheduler.syncAlarmStateWithNotification()
    }
    
    // The method will be called on the delegate when the user responded to the notification by opening the application, dismissing the notification or choosing a UNNotificationAction. The delegate must be set before the application returns from application:didFinishLaunchingWithOptions:.
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        print("📲 [didReceive] Notification: \(response.notification.request.identifier)")
        let userInfo = response.notification.request.content.userInfo
        guard
            let soundName = userInfo["soundName"] as? String,
            let uid = userInfo["uid"] as? String
        else {return}
        
        switch response.actionIdentifier {
        case Identifier.snoozeActionIdentifier:
            // notification fired when app in background, snooze button clicked
            notificationScheduler.setNotificationForSnooze(ringtoneName: soundName, snoozeMinute: 9, uid: uid)
            break
        case Identifier.stopActionIdentifier:
            // notification fired when app in background, ok button clicked
            let alarms = Store.shared.alarms
            break
        default:
            break
        }
        
        completionHandler()
    }
    
    //AlarmApplicationDelegate protocol
    // MARK: Play Sound
    // MARK: - Play Sound
    func playSound(_ soundName: String, localPath: String? = nil, completion: @escaping () -> Void) {
        print("🔊 Attempting to play sound: \(soundName)")

        // Vibrate first
        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        AudioServicesAddSystemSoundCompletion(SystemSoundID(kSystemSoundID_Vibrate), nil, nil, { _, _ in
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        }, nil)

        // 🔁 Reusable fallback player
        func playBundledFallbackSound() {
            let fallbackName = "bell"
            if let fallbackURL = Bundle.main.url(forResource: fallbackName, withExtension: "mp3") {
                do {
                    ExpoAlarmModule.audioPlayer = try AVAudioPlayer(contentsOf: fallbackURL)
                    ExpoAlarmModule.audioPlayer?.delegate = self
                    ExpoAlarmModule.audioPlayer?.numberOfLoops = -1
                    ExpoAlarmModule.audioPlayer?.prepareToPlay()
                    ExpoAlarmModule.audioPlayer?.play()
                    print("✅ Playing fallback \(fallbackName).mp3")
                } catch {
                    print("❌ AVAudioPlayer fallback error: \(error.localizedDescription)")
                }
            } else {
                print("❌ Fallback bell.mp3 not found in bundle")
            }
            completion()
        }

        // 🔊 Try to play any local file URL
        func playLocalFile(from url: URL, fallbackName: String = "bell", completion: @escaping () -> Void) {
            do {
                ExpoAlarmModule.audioPlayer = try AVAudioPlayer(contentsOf: url)
                ExpoAlarmModule.audioPlayer?.delegate = self
                ExpoAlarmModule.audioPlayer?.numberOfLoops = -1
                ExpoAlarmModule.audioPlayer?.prepareToPlay()
                ExpoAlarmModule.audioPlayer?.play()
                print("✅ Playing sound from: \(url.path)")
            } catch {
                print("❌ AVAudioPlayer error: \(error.localizedDescription)")
                playBundledFallbackSound()
            }
            completion()
        }

        // ✅ Check if localPath is provided and file exists
        if let localPath = localPath, FileManager.default.fileExists(atPath: localPath) {
            print("📦 Using pre-downloaded file at: \(localPath)")
            let localURL = URL(fileURLWithPath: localPath)
            playLocalFile(from: localURL, completion: completion)
            return
        }

        // 🔗 If it's a remote URL
        if soundName.hasPrefix("http://") || soundName.hasPrefix("https://") {
            print("🌐 Downloading remote audio: \(soundName)")
            guard let remoteURL = URL(string: soundName) else {
                print("❌ Invalid remote URL")
                playBundledFallbackSound()
                completion()
                return
            }

            // 🔐 SHA256 for filename
            let hash = sha256(of: soundName)
            let fileManager = FileManager.default
            let tempDir = fileManager.temporaryDirectory.appendingPathComponent("alarms", isDirectory: true)
            let localFileURL = tempDir.appendingPathComponent("\(hash).mp3")

            // ✅ If file already exists, use it
            if fileManager.fileExists(atPath: localFileURL.path) {
                print("📦 Cached file exists, playing directly.")
                playLocalFile(from: localFileURL, completion: completion)
                return
            }

            // Create alarms directory if needed
            try? fileManager.createDirectory(at: tempDir, withIntermediateDirectories: true)

            // Retry logic
            func downloadAndPlay(retryCount: Int = 0) {
                let config = URLSessionConfiguration.default
                config.timeoutIntervalForRequest = 15
                config.timeoutIntervalForResource = 20
                let session = URLSession(configuration: config)

                session.downloadTask(with: remoteURL) { downloadedURL, _, error in
                    if let error = error {
                        print("❌ Download failed [\(retryCount)]: \(error.localizedDescription)")
                        if retryCount < 2 {
                            print("🔁 Retrying...")
                            DispatchQueue.global().asyncAfter(deadline: .now() + 1.5) {
                                downloadAndPlay(retryCount: retryCount + 1)
                            }
                            return
                        }
                        print("⚠️ All retries failed. Falling back.")
                        playBundledFallbackSound()
                        completion()
                        return
                    }

                    guard let downloadedURL = downloadedURL else {
                        print("❌ Download URL is nil")
                        playBundledFallbackSound()
                        completion()
                        return
                    }

                    do {
                        try fileManager.moveItem(at: downloadedURL, to: localFileURL)
                        print("✅ Downloaded and saved to cache: \(localFileURL.path)")
                        playLocalFile(from: localFileURL, completion: completion)
                    } catch {
                        print("❌ Failed to move downloaded file: \(error.localizedDescription)")
                        playBundledFallbackSound()
                        completion()
                    }
                }.resume()
            }

            downloadAndPlay()
            return
        }

        // 📦 Try bundled resource
        if let bundledURL = Bundle.main.url(forResource: soundName, withExtension: "mp3") {
            print("📁 Playing bundled resource: \(soundName).mp3")
            playLocalFile(from: bundledURL, completion: completion)
        } else {
            print("⚠️ Bundled sound not found: \(soundName), using fallback")
            playBundledFallbackSound()
            completion()
        }
    }
}



func sha256(of string: String) -> String {
    guard let data = string.data(using: .utf8) else { return "" }
    var hash = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
    data.withUnsafeBytes {
        _ = CC_SHA256($0.baseAddress, CC_LONG(data.count), &hash)
    }
    return hash.map { String(format: "%02x", $0) }.joined()
}

